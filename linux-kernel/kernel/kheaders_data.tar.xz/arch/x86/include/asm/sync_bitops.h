/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_X86_SYNC_BITOPS_H
#define _ASM_X86_SYNC_BITOPS_H





#define ADDR (*(volatile long *)addr)


static inline void sync_set_bit(long nr, volatile unsigned long *addr)
{
	asm volatile("lock; bts %1,%0"
		     : "+m" (ADDR)
		     : "Ir" (nr)
		     : "memory");
}


static inline void sync_clear_bit(long nr, volatile unsigned long *addr)
{
	asm volatile("lock; btr %1,%0"
		     : "+m" (ADDR)
		     : "Ir" (nr)
		     : "memory");
}


static inline void sync_change_bit(long nr, volatile unsigned long *addr)
{
	asm volatile("lock; btc %1,%0"
		     : "+m" (ADDR)
		     : "Ir" (nr)
		     : "memory");
}


static inline int sync_test_and_set_bit(long nr, volatile unsigned long *addr)
{
	unsigned char oldbit;

	asm volatile("lock; bts %2,%1\n\tsetc %0"
		     : "=qm" (oldbit), "+m" (ADDR)
		     : "Ir" (nr) : "memory");
	return oldbit;
}


static inline int sync_test_and_clear_bit(long nr, volatile unsigned long *addr)
{
	unsigned char oldbit;

	asm volatile("lock; btr %2,%1\n\tsetc %0"
		     : "=qm" (oldbit), "+m" (ADDR)
		     : "Ir" (nr) : "memory");
	return oldbit;
}


static inline int sync_test_and_change_bit(long nr, volatile unsigned long *addr)
{
	unsigned char oldbit;

	asm volatile("lock; btc %2,%1\n\tsetc %0"
		     : "=qm" (oldbit), "+m" (ADDR)
		     : "Ir" (nr) : "memory");
	return oldbit;
}

#define sync_test_bit(nr, addr) test_bit(nr, addr)

#undef ADDR

#endif 
