/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_X86_HWCAP2_H
#define _ASM_X86_HWCAP2_H


#define HWCAP2_RING3MWAIT		(1 << 0)


#define HWCAP2_FSGSBASE			BIT(1)

#endif
